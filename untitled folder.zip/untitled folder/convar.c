#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>


//w strukturze usuwamy semafory i dodajemy zmienne warunkowe
typedef struct {
    pthread_mutex_t mutex;
    pthread_cond_t cond;
    int carA;
    int carB;
    int carsInCityA;
    int carsInCityB;
    int queuingInCityA;
    int queuingInCityB;
    int crossing;
    int direction;
} Bridge;

void cross(Bridge *b, int car_id, int direction);

typedef struct {
    long id;
    Bridge *bridge;
    int start_direction;
} temp;



void *car_thread(void *arg){
    temp *args = (temp*)arg;
    long tid = args->id;
    Bridge *bridge = args->bridge;

    int direction = args->start_direction;

    while (1) {
        if (direction == 0) {
            pthread_mutex_lock(&bridge->mutex);
            bridge->carsInCityA--;
            bridge->queuingInCityA++;
            pthread_mutex_unlock(&bridge->mutex);

            cross(bridge, tid, 0);

            direction = 1;
        } else {
            pthread_mutex_lock(&bridge->mutex);
            bridge->carsInCityB--;
            bridge->queuingInCityB++;
            pthread_mutex_unlock(&bridge->mutex);

            cross(bridge, tid, 1);

            direction = 0;
        }

        sleep(1);
    }

    free(args);
    return NULL;
}


void cross(Bridge *b, int car_id, int direction) {
    pthread_mutex_lock(&b->mutex);

    // petla ktora czeka az most bedzie wolny i kierunek przejazdu jest zgodny
    while (b->crossing > 0 || (b->direction != -1 && b->direction != direction)) {
        pthread_cond_wait(&b->cond, &b->mutex);
    }

    // Wjazd na most
    b->crossing = 1;
    b->direction = direction;

    // informacja o przejezdzie i aktualizacja wartosci
    if (direction == 0) {
        b->queuingInCityA--;
        printf("A-%d %d>>> [>> %d >>] <<< %d %d-B\n", b->carsInCityA, b->queuingInCityA, car_id, b->queuingInCityB, b->carsInCityB);
        b->carsInCityB++;
    } else {
        b->queuingInCityB--;
        printf("A-%d %d>>> [<< %d <<] <<< %d %d-B\n", b->carsInCityA, b->queuingInCityA, car_id, b->queuingInCityB, b->carsInCityB);
        b->carsInCityA++;
    }

    pthread_mutex_unlock(&b->mutex);

    usleep(500000);
    //koniec przejazdu
    pthread_mutex_lock(&b->mutex);
    b->crossing = 0;
    b->direction = -1;
    // sygnalizacja: zwolnienie mostu
    pthread_cond_broadcast(&b->cond);
    pthread_mutex_unlock(&b->mutex);
}


int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Wrong usage! Type ./most {N}\n");
        return 1;
    }
    int N = atoi(argv[1]);
    if (N < 1) {
        printf("Number of cars should be higher!\n");
    }
    if (N > 100) {
        printf("Number of cars should be lower!\n");
    }   
    Bridge bridge = {
        .carsInCityA = 0,
        .carsInCityB = 0,
        .queuingInCityA = 0,
        .queuingInCityB = 0,
        .crossing = -1,
        .direction = -1
    };
    //inicjalizacja zmiennej warunkowej
    pthread_mutex_init(&bridge.mutex, NULL);
    pthread_cond_init(&bridge.cond, NULL);
    srand(time(NULL));
    pthread_t threads[N];
    int rc;
    for (long i = 0; i < N; i++){
        temp *args = malloc(sizeof(temp));
        args-> id = i + 1;
        args->bridge = &bridge;
        int r = rand() % 2;
        if (r == 0) {
            bridge.carsInCityA++;
            args->start_direction = 0;
        } else {
            bridge.carsInCityB++;
            args->start_direction = 1;
        }
            rc = pthread_create(&threads[i], NULL , car_thread, (void*)args);
            if (rc){
               printf("ERROR; return code from pthread_create() is %d\n", rc);
               exit(-1);
            }
    }
    pthread_exit(NULL);
}