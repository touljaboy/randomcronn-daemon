#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>



//struktura mostu trzymajaca info o samochodach i kto przejezdza w jakim kierunku
//trzyma takze semafory i mutex, ktore watki uzywaja do synchronizacji
typedef struct {
    pthread_mutex_t mutex;
    sem_t sem;
    sem_t start_sem;
    int carA;
    int carB;
    int carsInCityA;
    int carsInCityB;
    int queuingInCityA;
    int queuingInCityB;
    int crossing;
    int direction;
} Bridge;


//inicjalizacja funkcji cross
void cross(Bridge *b, int car_id, int direction);

// strukt pomocniczy zeby przekazywac 3 argumenty do watku
typedef struct {
    long id;
    Bridge *bridge;
    int start_direction;
} temp;


// funkcja, ktora watek otrzymuje podczas inicjalizacji
//przekazywany jest id watku, pointer do struktury mostu i wylosowany kierunek
void *car_thread(void *arg){
    temp *args = (temp*)arg;
    long tid = args->id;
    Bridge *bridge = args->bridge;

    //uzywamy semafora zeby zatrzymac watki, ruszaja one dopiero po pojawieniu
    //sie wszystkich samochodow
    sem_wait(&bridge->start_sem);

    int direction = args->start_direction;
    //petla dzieki ktorej samochody przejezdzaja z jednego miasta do drugiego
    //i z powrotem
    while (1) {
        if (direction == 0) {
            //samochod jest w miescie A
            // wchodzi do kolejki w A
            pthread_mutex_lock(&bridge->mutex);
            bridge->carsInCityA--;
            bridge->queuingInCityA++;
            pthread_mutex_unlock(&bridge->mutex);
            //przejezdza do drugiego miasta
            cross(bridge, tid, 0);

            //zmieniamy kierunek trasy
            direction = 1;
        } else {
            // wchodzi do kolejki w B
            pthread_mutex_lock(&bridge->mutex);
            bridge->carsInCityB--;
            bridge->queuingInCityB++;
            pthread_mutex_unlock(&bridge->mutex);

            cross(bridge, tid, 1);

            direction = 0;
        }
        //pauza zeby inne watki tez sie ruszaly
        sleep(1);
    }
    free(args);
    return NULL;
}

//funkcja przejazdu, argumenty to pointer do mostu, id samochodu i kierunek
void cross(Bridge *b, int car_id, int direction){
    // samochod czeka az most sie zwolni
    sem_wait(&b->sem);
    //uzywamy mutexa by zmienic wartosci w bridge
    pthread_mutex_lock(&b->mutex);
    //informacje dotyczace samochodu przejezdzajacego
    b->crossing = car_id;
    b->direction = direction;
    //print z informacja o stanie programu
    if (b->direction == 0){
        b->queuingInCityA--;
        printf("A-%d %d>>> [>> %d >>] <<< %d %d-B\n", b->carsInCityA, b->queuingInCityA, b->crossing, b->queuingInCityB, b->carsInCityB);
        b->carsInCityB++;
    }
    if (b->direction == 1){
        b->queuingInCityB--;
        printf("A-%d %d>>> [<< %d <<] <<< %d %d-B\n", b->carsInCityA, b->queuingInCityA, b->crossing, b->queuingInCityB, b->carsInCityB);
        b->carsInCityA++;
    }
    //po przejechaniu informujemy ze most jest wolny
    b->crossing = -1;
    pthread_mutex_unlock(&b->mutex);
    usleep(500000);
    //zwalniamy semafore
    sem_post(&b->sem);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Wrong usage! Type ./most {N}\n");
        return 1;
    }
    int N = atoi(argv[1]);
    if (N < 1) {
        printf("Number of cars should be higher!\n");
    }
    if (N > 100) {
        printf("Number of cars should be lower!\n");
    }
    //inicjalizacja semafor i struktury mostu
    sem_t bridge_sem;
    sem_t bridge_start_sem;
    sem_init(&bridge_start_sem, 0, 0);
    sem_init(&bridge_sem, 0, 1);    
    Bridge bridge = {
        .sem = bridge_sem,
        .carsInCityA = 0,
        .carsInCityB = 0,
        .queuingInCityA = 0,
        .queuingInCityB = 0,
        .crossing = -1,
        .direction = -1
    };
    srand(time(NULL));
    pthread_t threads[N];
    int rc;
    for (long i = 0; i < N; i++){
        temp *args = malloc(sizeof(temp));
        args-> id = i + 1;
        args->bridge = &bridge;
        //losujemy miasto w ktorym pojawi sie samochod, tym samym kierunek
        int r = rand() % 2;
        if (r == 0) {
            bridge.carsInCityA++;
            args->start_direction = 0;
        } else {
            bridge.carsInCityB++;
            args->start_direction = 1;
        }
            rc = pthread_create(&threads[i], NULL , car_thread, (void*)args);
            if (rc){
               printf("ERROR; return code from pthread_create() is %d\n", rc);
               exit(-1);
            }
    }
    //petla, ktora pozwala watkam rozpoczac dzialanie dopiero po stworzeniu wszystkich watkow
    for (int i = 0; i < N; i++) {
        sem_post(&bridge.start_sem);
    }
    pthread_exit(NULL);
}